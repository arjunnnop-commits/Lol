package com.yooitachiijod.glassfastboot

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Intro: black & white. The logo fades in, the girl appears and "FAIRY TEAM" gets written with a glowing pen tip. */
@Composable
fun Root(vm: FlashViewModel) {
    var splash by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(5000)
        splash = false
    }
    Crossfade(targetState = splash, animationSpec = tween(700), label = "root") { showSplash ->
        if (showSplash) FairySplash() else App(vm)
    }
}

@Composable
fun FairySplash() {
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val logoA by animateFloatAsState(if (started) 1f else 0f, tween(1100), label = "logo")
    val girlA by animateFloatAsState(if (started) 1f else 0f, tween(1200, delayMillis = 500), label = "girl")
    val write by animateFloatAsState(
        if (started) 1f else 0f,
        tween(2300, delayMillis = 1500, easing = CubicBezierEasing(0.35f, 0f, 0.35f, 1f)),
        label = "write"
    )
    val subA = ((write - 0.85f) / 0.15f).coerceIn(0f, 1f)

    val t = rememberInfiniteTransition(label = "glow")
    val pulse by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(
            painter = painterResource(R.drawable.fairy_logo),
            contentDescription = null,
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 56.dp)
                .fillMaxWidth(0.58f).alpha(logoA),
            contentScale = ContentScale.Fit
        )

        // the name, revealed left to right like it is being written
        Column(
            Modifier.align(Alignment.Center).offset(y = (-10).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.drawWithContent {
                    drawContent()
                    if (write > 0.002f && write < 0.995f) {
                        val raw = write * 1.15f
                        val x = size.width * (raw - 0.075f).coerceIn(0f, 1f)
                        val y = size.height * 0.62f
                        val r = 46f + 14f * pulse
                        drawCircle(
                            brush = Brush.radialGradient(listOf(Color.White, Color.Transparent), center = Offset(x, y), radius = r),
                            radius = r,
                            center = Offset(x, y)
                        )
                    }
                }
            ) {
                Text(
                    "FAIRY TEAM",
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            val raw = write * 1.15f
                            val b = raw.coerceAtMost(1f)
                            val a = (raw - 0.15f).coerceIn(0f, 1f)
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    0f to Color.Black, a to Color.Black, b to Color.Transparent, 1f to Color.Transparent,
                                    startX = 0f, endX = size.width
                                ),
                                blendMode = BlendMode.DstIn
                            )
                        },
                    style = TextStyle(
                        color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp,
                        shadow = Shadow(Color.White.copy(alpha = 0.55f), Offset.Zero, 22f)
                    )
                )
            }
            Text(
                "F L A S H E R",
                modifier = Modifier.padding(top = 6.dp).alpha(subA),
                style = TextStyle(color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, letterSpacing = 4.sp)
            )
        }

        // the girl, bottom left
        Image(
            painter = painterResource(R.drawable.fairy_girl),
            contentDescription = null,
            modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth(0.78f)
                .offset(x = (-24f * (1f - girlA)).dp).alpha(girlA),
            contentScale = ContentScale.FillWidth
        )
    }
}
