package com.yooitachiijod.glassfastboot

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Black & white palette (names kept so the other files still compile)
val Ice = Color.White
val Violet = Color(0xFFD0D0D0)
val Pink = Color(0xFF8C8C8C)

@Composable
fun GlassTheme(content: @Composable () -> Unit) =
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color.White, onPrimary = Color.Black,
            background = Color.Black, surface = Color.Black
        ),
        content = content
    )

/** Pure AMOLED black with a few very faint white "liquid" blobs drifting behind the glass. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Blob(Color.White, (-60 + 120 * a).dp, 40.dp, 300.dp)
        Blob(Color(0xFFBDBDBD), (180 - 140 * a).dp, 260.dp, 280.dp)
        Blob(Color(0xFF8C8C8C), (-40 + 80 * a).dp, 560.dp, 260.dp)
        content()
    }
}

@Composable
private fun Blob(c: Color, x: androidx.compose.ui.unit.Dp, y: androidx.compose.ui.unit.Dp, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.offset(x, y).size(size).blur(70.dp)
            .background(Brush.radialGradient(listOf(c.copy(alpha = .16f), Color.Transparent)), CircleShape)
    )
}

private val glassFill = Brush.linearGradient(listOf(Color.White.copy(.13f), Color.White.copy(.04f)))
private val glassEdge = Brush.linearGradient(listOf(Color.White.copy(.60f), Color.White.copy(.05f), Color.White.copy(.28f)))
private val accentFill = Brush.linearGradient(listOf(Color.White.copy(.34f), Color.White.copy(.12f)))
private val clearFill = Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(glassFill).border(1.dp, glassEdge, shape).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, accent: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill = if (accent) accentFill else glassFill
    Box(
        modifier.alpha(if (enabled) 1f else .4f).clip(shape).background(fill).border(1.dp, glassEdge, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun GlassChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) accentFill else glassFill)
            .border(1.dp, glassEdge, shape).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    ) { Text(text, color = Color.White, fontSize = 12.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) }
}

@Composable
fun GlassTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(glassFill).border(1.dp, glassEdge, shape).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(shape)
                    .background(if (on) accentFill else clearFill)
                    .clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = Color.White, fontSize = 13.sp, maxLines = 1,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}
