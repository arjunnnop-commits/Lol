package com.yooitachiijod.glassfastboot

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.channels.FileChannel

/** A zip entry that is only unpacked when it is its turn to be flashed. */
class ZipSource(val uri: Uri?, val file: File?, val entry: ZEntry)

class FlashItem(
    val uri: Uri, val name: String, val size: Long, partition: String,
    val temp: File? = null, val zip: ZipSource? = null
) {
    var partition by mutableStateOf(partition)
}

/** One parsed command of a .bat / .sh flashing script. */
class ScriptStep(
    val kind: String,            // flash, erase, wipe, set_active, reboot, cmd, note
    val label: String,
    val partition: String = "",
    val cmd: String = "",
    val fileName: String = "",
    val uri: Uri? = null,
    val size: Long = 0L,
    val slot: String? = null,
    val verity: Boolean = false,
    val missing: Boolean = false
)

private class Imported {
    var count = 0
    var payload = false
}

class FlashViewModel(app: Application) : AndroidViewModel(app) {
    companion object { const val ACTION_PERM = "com.yooitachiijod.glassfastboot.USB_PERMISSION" }

    private val ctx get() = getApplication<Application>()
    private val usb = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
    private var client: FastbootClient? = null
    private var adb: AdbClient? = null

    var connected by mutableStateOf(false); private set
    var adbConnected by mutableStateOf(false); private set
    var adbBanner by mutableStateOf(""); private set
    var busy by mutableStateOf(false); private set
    var progress by mutableFloatStateOf(0f); private set
    val info = mutableStateMapOf<String, String>()
    val items = mutableStateListOf<FlashItem>()
    val logLines = mutableStateListOf<String>()
    var slotMode by mutableStateOf("current")
    var disableVerity by mutableStateOf(false)
    var scriptName by mutableStateOf("")
    var imagesName by mutableStateOf("")
    var imageCount by mutableIntStateOf(0)
    var skipMissing by mutableStateOf(false)
    val scriptSteps = mutableStateListOf<ScriptStep>()
    private var scriptLines: List<String> = emptyList()
    private var imageIndex: Map<String, Pair<Uri, Long>> = emptyMap()
    private var maxDownload = 256L * 1024 * 1024

    fun log(m: String) {
        logLines.add(m)
        if (logLines.size > 500) logLines.removeAt(0)
    }

    // ---------- USB connect ----------
    fun scan() {
        if (client != null || adb != null || busy) return
        for (d in usb.deviceList.values) {
            val isFb = FastbootClient.findInterface(d) != null
            val isAdb = AdbClient.findInterface(d) != null
            if (!isFb && !isAdb) continue
            if (usb.hasPermission(d)) {
                if (isFb) connect(d) else connectAdb(d)
            } else {
                val pi = PendingIntent.getBroadcast(
                    ctx, 0, Intent(ACTION_PERM).setPackage(ctx.packageName), PendingIntent.FLAG_MUTABLE
                )
                usb.requestPermission(d, pi)
            }
            return
        }
    }

    private fun connectAdb(d: UsbDevice) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val a = AdbClient.open(usb, d, ::log, File(ctx.filesDir, "adbkey.pk8"))
                adb = a
                val banner = a.connect()
                adbBanner = banner; adbConnected = true
                log("✔ ADB connected: $banner")
                if (!banner.contains("sideload")) log("ℹ For sideload, boot to recovery and choose 'Apply update from ADB'")
            } catch (e: Exception) {
                adb?.close(); adb = null
                log("✖ ADB: ${e.message}")
            }
        }
    }

    private fun connect(d: UsbDevice) { viewModelScope.launch(Dispatchers.IO) { connectBlocking(d) } }

    private fun connectBlocking(d: UsbDevice) {
        run {
            try {
                val c = FastbootClient.open(usb, d, ::log)
                client = c
                fun v(n: String) = try { c.command("getvar:$n") } catch (_: Exception) { "?" }
                for (k in listOf("product", "current-slot", "slot-count", "unlocked", "is-userspace", "serialno", "secure")) info[k] = v(k)
                val md = v("max-download-size")
                info["max-download-size"] = md
                md.removePrefix("0x").toLongOrNull(16)?.let { if (it > 0) maxDownload = it }
                connected = true
                log("✔ Fastboot device connected (${info["product"]})")
            } catch (e: Exception) {
                client?.close(); client = null
                log("✖ Connect: ${e.message}")
            }
        }
    }

    fun onDetached() {
        if (client != null || adb != null) log("⏏ Device disconnected")
        disconnect()
    }

    private fun disconnect() {
        client?.close(); client = null
        adb?.close(); adb = null
        connected = false; adbConnected = false; adbBanner = ""; info.clear()
    }

    // ---------- files ----------
    private fun meta(u: Uri): Pair<String, Long> {
        var name = "file"; var size = 0L
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni)
                if (si >= 0) size = c.getLong(si)
            }
        }
        return name to size
    }

    private fun guessPartition(name: String): String {
        val stem = name.substringBeforeLast('.')
        return when {
            stem.startsWith("bootloader-") -> "bootloader"
            stem.startsWith("radio-") -> "radio"
            else -> stem
        }
    }

    /** super / userdata go last, everything else keeps its order. */
    private fun weight(n: String) = if (n.startsWith("super") || n.startsWith("userdata")) 1 else 0

    fun addFiles(uris: List<Uri>) {
        for (u in uris) {
            val (name, size) = meta(u)
            items.add(FlashItem(u, name, size, guessPartition(name)))
        }
    }

    /** Opens the archive (content uri or a cached file) as a seekable channel. */
    private fun <T> withArchive(uri: Uri?, file: File?, block: (FileChannel) -> T): T {
        if (file != null) return RandomAccessFile(file, "r").use { block(it.channel) }
        val u = uri ?: throw FastbootException("Archive source missing")
        val pfd = ctx.contentResolver.openFileDescriptor(u, "r") ?: throw FastbootException("Cannot open the archive")
        return pfd.use { p -> FileInputStream(p.fileDescriptor).use { block(it.channel) } }
    }

    private fun lazyItem(src: ZipSource): FlashItem {
        val base = src.entry.name.substringAfterLast('/')
        val u = src.uri ?: src.file?.let { Uri.fromFile(it) } ?: Uri.EMPTY
        return FlashItem(u, base, src.entry.usize, guessPartition(base), null, src)
    }

    private fun isImg(e: ZEntry): Boolean {
        val base = e.name.substringAfterLast('/')
        return !e.name.endsWith("/") && (base.endsWith(".img", ignoreCase = true) || (base.endsWith(".bin", ignoreCase = true) && !base.equals("payload.bin", ignoreCase = true))) && base != "super_empty.img"
    }

    /** Lists every .img in the zip without unpacking anything, so ALL images show up at once. */
    private fun indexZip(uri: Uri, dir: File, res: Imported): List<FlashItem> {
        val found = ArrayList<FlashItem>()
        val entries = withArchive(uri, null) { ch -> ZipIndex.list(ch) }
        val nested = ArrayList<ZEntry>()
        for (e in entries) {
            if (e.name.endsWith("/")) continue
            val base = e.name.substringAfterLast('/')
            when {
                isImg(e) -> found.add(lazyItem(ZipSource(uri, null, e)))
                base == "payload.bin" -> res.payload = true
                base.endsWith(".zip", ignoreCase = true) && base.startsWith("image", ignoreCase = true) -> nested.add(e)
            }
        }
        // Pixel-style factory zips keep the real images inside image-*.zip
        for (e in nested) {
            val base = e.name.substringAfterLast('/')
            val inner = File(dir, "nested_${System.nanoTime()}.zip")
            try {
                val need = e.usize + (64L shl 20)
                if (dir.usableSpace < need) throw FastbootException("not enough free storage to open $base (needs ${need / 1048576} MB)")
                log("  opening $base (${e.usize / 1048576} MB) …")
                withArchive(uri, null) { ch -> ZipIndex.extractEntry(ch, e, inner) { } }
                val innerEntries = withArchive(null, inner) { ch -> ZipIndex.list(ch) }
                for (ie in innerEntries) {
                    if (isImg(ie)) found.add(lazyItem(ZipSource(null, inner, ie)))
                    else if (ie.name.substringAfterLast('/') == "payload.bin") res.payload = true
                }
            } catch (ex: Exception) {
                inner.delete()
                log("  ✖ $base: ${ex.message}")
            }
        }
        return found
    }

    /** ROM zip / tgz → every .img inside is listed and queued for flashing. */
    fun importArchive(uri: Uri) {
        if (busy) return
        busy = true; progress = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val (name, _) = meta(uri)
                val lower = name.lowercase()
                log("📦 Reading $name …")
                val dir = File(ctx.cacheDir, "rom")
                dir.deleteRecursively(); dir.mkdirs()
                val res = Imported()
                val isTar = lower.endsWith(".tgz") || lower.endsWith(".tar.gz") || lower.endsWith(".tar")
                var done = false
                if (!isTar) {
                    try {
                        val found = indexZip(uri, dir, res).sortedBy { weight(it.name) }
                        found.forEach { items.add(it) }
                        res.count = found.size
                        done = true
                    } catch (e: Exception) {
                        log("ℹ Direct zip index failed (${e.message}) — using sequential extraction")
                        res.payload = false
                    }
                }
                if (!done) {
                    val r = ctx.contentResolver.openInputStream(uri)?.use { s ->
                        Archive.extractImages(s, name, dir, ::log) { f ->
                            items.add(FlashItem(Uri.fromFile(f), f.name, f.length(), guessPartition(f.name), f))
                            res.count++
                        }
                    } ?: throw FastbootException("Cannot open the archive")
                    if (r.hasPayload) res.payload = true
                }
                when {
                    res.count > 0 -> log("✔ ${res.count} image(s) listed — check the partition names, then tap Flash")
                    res.payload -> log("This is an OTA zip (payload.bin) — fastboot can't flash it. Use the Custom ROM tab and sideload it.")
                    else -> log("No .img files found in this archive")
                }
            } catch (e: Exception) {
                log("✖ Import: ${e.message}")
            } finally { busy = false }
        }
    }

    // ---------- operations ----------
    private fun runOp(title: String, block: (FastbootClient) -> Unit) {
        val c = client ?: run { log("No fastboot device connected"); return }
        if (busy) return
        busy = true; progress = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try {
                log("▶ $title")
                block(c)
                log("✔ $title — done")
            } catch (e: Exception) {
                log("✖ ${e.message}")
            } finally { busy = false; progress = 0f }
        }
    }

    /** Unpacks one zip entry into the cache right before it is flashed (one image at a time). */
    private fun materialize(item: FlashItem, onFrac: (Float) -> Unit): File {
        val z = item.zip ?: throw FastbootException("Not an archive entry: ${item.name}")
        val dir = File(ctx.cacheDir, "rom"); dir.mkdirs()
        val need = z.entry.usize + (64L shl 20)
        val free = dir.usableSpace
        if (free < need) throw FastbootException(
            "Not enough free storage to unpack ${item.name}: needs ${need / 1048576} MB, only ${free / 1048576} MB free"
        )
        val out = File(dir, "x_${System.nanoTime()}.img")
        try {
            withArchive(z.uri, z.file) { ch -> ZipIndex.extractEntry(ch, z.entry, out, onFrac) }
        } catch (e: Exception) {
            out.delete(); throw e
        }
        return out
    }

    private fun hint(msg: String?) {
        val m = (msg ?: "").lowercase()
        if ("partition" in m || "not allowed" in m || "not found" in m || "unknown" in m) {
            log("  ℹ Logical partitions (system, vendor, product, system_ext …) can only be flashed from FastbootD — tap “FastbootD” in Quick actions, or flash super.img instead.")
        }
    }

    fun flashAll() {
        val list = items.toList().sortedBy { weight(it.name) }
        if (list.isEmpty()) return
        runOp("Flash ${list.size} image(s)") { c ->
            val failed = ArrayList<String>()
            list.forEachIndexed { i, item ->
                log("→ ${item.name}  ⇒  ${item.partition}")
                var tmp: File? = null
                try {
                    val lazy = item.zip != null
                    val base = if (lazy) 0.4f else 0f
                    val uri = if (lazy) {
                        log("  unpacking ${item.name} (${item.size / 1048576} MB) …")
                        val f = materialize(item) { fr -> progress = (i + fr * base) / list.size }
                        tmp = f
                        Uri.fromFile(f)
                    } else item.uri
                    flashOne(c, item, uri, slotMode, disableVerity) { fr -> progress = (i + base + fr * (1f - base)) / list.size }
                    if (item.zip != null || item.temp != null) items.remove(item)
                    item.temp?.delete()
                } catch (e: Exception) {
                    failed.add(item.name)
                    log("  ✖ ${item.name}: ${e.message}")
                    hint(e.message)
                } finally {
                    tmp?.delete()
                }
            }
            if (failed.isNotEmpty()) {
                throw FastbootException("${failed.size} of ${list.size} image(s) failed: ${failed.joinToString()} (they stay in the list so you can retry)")
            }
        }
    }

    private fun flashOne(c: FastbootClient, item: FlashItem, uri: Uri, slot: String, verity: Boolean, onFrac: (Float) -> Unit) {
        for (target in c.resolveTargets(item.partition, slot)) {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
                ?: throw FastbootException("Cannot open file: ${item.name}")
            pfd.use {
                val size = it.statSize
                FileInputStream(it.fileDescriptor).use { fis ->
                    val ch = fis.channel
                    if (verity && target.startsWith("vbmeta") && size < 4 * 1024 * 1024) {
                        val b = ByteArray(size.toInt()); var r = 0
                        ch.position(0)
                        while (r < b.size) { val n = fis.read(b, r, b.size - r); if (n < 0) break; r += n }
                        if (b.size > 124 && String(b, 0, 4) == "AVB0") {
                            b[123] = (b[123].toInt() or 3).toByte()
                            log("  vbmeta: verity+verification disabled")
                        }
                        c.flash(target, ByteArrayInputStream(b), b.size.toLong(), onFrac)
                        return@use
                    }
                    if (size <= maxDownload) {
                        ch.position(0)
                        log("  flashing $target (${size / 1048576} MB)")
                        c.flash(target, fis, size, onFrac)
                    } else {
                        val layout = if (Sparse.isSparse(ch)) Sparse.parse(ch) else Sparse.rawLayout(size)
                        val pieces = Sparse.plan(layout, maxDownload)
                        log("  big image → ${pieces.size} piece(s) for $target")
                        pieces.forEachIndexed { idx, pc ->
                            log("  piece ${idx + 1}/${pieces.size}")
                            val f = File(ctx.cacheDir, "piece_$idx.simg")
                            try {
                                Sparse.write(ch, layout, pc, f)
                                FileInputStream(f).use { s ->
                                    c.flash(target, s, f.length()) { fr -> onFrac((idx + fr) / pieces.size) }
                                }
                            } finally { f.delete() }
                        }
                    }
                }
            }
        }
    }

    /** Console routes explicitly prefixed adb/shell commands to ADB; otherwise uses Fastboot. */
    fun raw(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        if (busy) return
        val wantsAdb = text.startsWith("adb ", true) || text.startsWith("shell ", true)
        val adbCommand = when {
            text.startsWith("adb ", true) -> text.substring(4).trim().removePrefix("shell ")
            text.startsWith("shell ", true) -> text.substring(6).trim()
            else -> ""
        }
        if (wantsAdb) {
            val a = adb ?: run { log("✖ No ADB device connected. Enable USB debugging and authorize this computer."); return }
            if (adbCommand.isBlank()) { log("Usage: adb shell <command>"); return }
            busy = true
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    log("$ adb shell $adbCommand")
                    val result = a.shell(adbCommand)
                    log(if (result.isNotBlank()) result else "(no output)")
                } catch (e: Exception) { log("✖ ADB shell: ${e.message}") }
                finally { busy = false }
            }
            return
        }
        val c = client ?: run {
            log("✖ No Fastboot device connected. For ADB shell, enter: adb shell getprop ro.product.device")
            return
        }
        if (text.equals("help", true)) {
            log("Fastboot: getvar:product, getvar:current-slot, reboot, reboot-bootloader")
            log("ADB: adb shell getprop ro.product.device")
            return
        }
        runOp(text) { fb ->
            val result = fb.command(text, 120000) { log(it) }
            log(if (result.isNotBlank()) result else "(no output)")
        }
    }

    fun reboot(cmd: String) {
        val c = client ?: return
        viewModelScope.launch(Dispatchers.IO) {
            log("↻ $cmd")
            c.sendNoReply(cmd)
            disconnect()
        }
    }

    private fun refreshSlot(c: FastbootClient) {
        try { info["current-slot"] = c.command("getvar:current-slot") } catch (_: Exception) { }
    }

    fun setActive(slot: String) = runOp("Set active slot $slot") { c ->
        c.command("set_active:$slot")
        refreshSlot(c)
    }

    fun unlock() = runOp("Unlock bootloader (confirm on the phone)") { c ->
        try { c.command("flashing unlock", 120000) { log(it) } }
        catch (e: Exception) { log("flashing unlock failed → trying oem unlock"); c.command("oem unlock", 120000) { log(it) } }
    }

    fun lock() = runOp("Lock bootloader") { c ->
        try { c.command("flashing lock", 120000) { log(it) } }
        catch (e: Exception) { c.command("oem lock", 120000) { log(it) } }
    }

    fun wipe() = runOp("Wipe data") { c ->
        c.command("erase:userdata", 300000) { log(it) }
        try { c.command("erase:metadata", 120000) { log(it) } } catch (e: Exception) { log("metadata skipped: ${e.message}") }
    }

    fun sideload(uri: Uri) {
        val a = adb ?: run { log("No ADB / recovery device connected"); return }
        if (busy) return
        busy = true; progress = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try {
                log("▶ Sideload started (keep 'Apply update from ADB' open on the phone)")
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw FastbootException("Cannot open file")
                pfd.use { p ->
                    FileInputStream(p.fileDescriptor).use { fis -> a.sideload(fis.channel, p.statSize) { f -> progress = f } }
                }
                log("✔ Sideload complete — check the result on the phone's recovery screen")
            } catch (e: Exception) {
                log("✖ ${e.message}")
            } finally { busy = false; progress = 0f }
        }
    }

    // ---------- script flashing (.bat / .sh) ----------
    private val varRe = Regex("%~[A-Za-z0-9]*|%[^%\\s]*%|\\\$\\{[^}]*\\}|\\\$[A-Za-z_][A-Za-z0-9_]*")

    fun loadScript(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val (name, _) = meta(uri)
                val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                    ?: throw FastbootException("Cannot open the script")
                scriptName = name
                scriptLines = text.removePrefix("\uFEFF").replace("\r", "").split('\n')
                rebuildSteps()
                log("📜 $name: ${scriptSteps.size} step(s) found")
                if (scriptSteps.isEmpty()) log("  ℹ no fastboot commands found in this script")
            } catch (e: Exception) {
                log("✖ Script: ${e.message}")
            }
        }
    }

    fun loadImagesFolder(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val root = DocumentFile.fromTreeUri(ctx, uri) ?: throw FastbootException("Cannot open the folder")
                val map = HashMap<String, Pair<Uri, Long>>()
                fun walk(d: DocumentFile, depth: Int) {
                    for (f in d.listFiles()) {
                        val n = f.name ?: continue
                        if (f.isDirectory) {
                            if (depth < 4) walk(f, depth + 1)
                        } else {
                            val k = n.lowercase()
                            if (!map.containsKey(k)) map[k] = Pair(f.uri, f.length())
                        }
                    }
                }
                walk(root, 0)
                imageIndex = map
                imagesName = root.name ?: "folder"
                imageCount = map.size
                rebuildSteps()
                log("📁 $imagesName: ${map.size} file(s)")
            } catch (e: Exception) {
                log("✖ Folder: ${e.message}")
            }
        }
    }

    private fun rebuildSteps() {
        val st = parseScript(scriptLines)
        scriptSteps.clear()
        scriptSteps.addAll(st)
    }

    private fun tokenize(line: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = '\u0000'
        var has = false
        for (ch in line) {
            when {
                q != '\u0000' -> if (ch == q) q = '\u0000' else sb.append(ch)
                ch == '"' || ch == '\'' -> { q = ch; has = true }
                ch.isWhitespace() -> {
                    if (sb.isNotEmpty() || has) { out.add(sb.toString()); sb.clear(); has = false }
                }
                else -> sb.append(ch)
            }
        }
        if (sb.isNotEmpty() || has) out.add(sb.toString())
        return out
    }

    private fun isFastbootTok(t: String): Boolean {
        val b = t.trim('@', '%', '$', '{', '}').lowercase().substringAfterLast('/').substringAfterLast('\\')
        return b == "fastboot" || b == "fastboot.exe"
    }

    private fun isOp(t: String) = t == "&&" || t == "||" || t == "|" || t == "&" || t == ";" ||
        t.startsWith(">") || t.startsWith("2>") || t.startsWith("1>") || t.startsWith("&>") || t.startsWith("<")

    private fun cleanName(tok: String): String =
        tok.replace(varRe, "").trim().trim('"', '\'').substringAfterLast('/').substringAfterLast('\\')

    private fun parseScript(lines: List<String>): List<ScriptStep> {
        val isBat = scriptName.lowercase().let { it.endsWith(".bat") || it.endsWith(".cmd") }
        val cont = if (isBat) '^' else '\\'
        val joined = ArrayList<String>()
        var acc = StringBuilder()
        for (raw in lines) {
            val l = raw.trimEnd()
            if (l.isNotEmpty() && l.last() == cont) { acc.append(l.dropLast(1)).append(' '); continue }
            acc.append(l)
            joined.add(acc.toString())
            acc = StringBuilder()
        }
        if (acc.isNotEmpty()) joined.add(acc.toString())

        val out = ArrayList<ScriptStep>()
        for (line0 in joined) {
            val line = line0.trim()
            val low = line.lowercase()
            if (line.isEmpty() || low == "rem" || low.startsWith("rem ") || line.startsWith("::") || line.startsWith("#") ||
                low.startsWith("echo") || low.startsWith("@echo") || low.startsWith("set ") || low.startsWith("export ") ||
                line.startsWith(":")) continue
            val toks = tokenize(line)
            val fi = toks.indexOfFirst { isFastbootTok(it) }
            if (fi < 0) continue
            var args = toks.drop(fi + 1)
            val cut = args.indexOfFirst { isOp(it) }
            if (cut >= 0) args = args.take(cut)
            parseArgs(args, out)
        }
        return out
    }

    private fun parseArgs(args: List<String>, out: MutableList<ScriptStep>) {
        var slot: String? = null
        var verity = false
        var wipe = false
        var active: String? = null
        val pos = ArrayList<String>()
        val argRe = Regex("%[0-9]")
        var i = 0
        while (i < args.size) {
            val t = args[i]
            when {
                t == "%*" || t == "\$@" || t == "\$*" || argRe.matches(t) -> { }
                t == "-s" || t == "-S" || t == "-i" || t == "-b" || t == "-c" || t == "-n" -> i++
                t == "--slot" -> { slot = args.getOrNull(i + 1); i++ }
                t.startsWith("--slot=") -> slot = t.substringAfter('=')
                t.startsWith("--set-active=") -> active = t.substringAfter('=')
                t == "-w" -> wipe = true
                t == "--disable-verity" || t == "--disable-verification" -> verity = true
                t.startsWith("-") -> { }
                else -> pos.add(t)
            }
            i++
        }
        val sl = slot?.lowercase()?.let { if (it == "a" || it == "b" || it == "all") it else "current" }
        if (wipe) out.add(ScriptStep("wipe", "wipe data (fastboot -w)"))
        if (pos.isEmpty()) {
            if (active != null) out.add(ScriptStep("set_active", "set active slot $active", partition = active))
            return
        }
        val base = pos[0].lowercase().substringBefore(':')
        when (base) {
            "flash" -> {
                if (pos.size < 3) return
                var part = pos[1]
                var s2 = sl
                if (part.endsWith("_ab")) { part = part.dropLast(3); s2 = "all" }
                val fname = cleanName(pos[2])
                val f = imageIndex[fname.lowercase()]
                val tag = if (s2 != null) "  [slot $s2]" else ""
                out.add(
                    ScriptStep(
                        "flash", "flash $part ← $fname$tag", partition = part, fileName = fname,
                        uri = f?.first, size = f?.second ?: 0L, slot = s2, verity = verity, missing = f == null
                    )
                )
            }
            "erase" -> {
                if (pos.size >= 2) out.add(ScriptStep("erase", "erase ${pos[1]}", partition = pos[1]))
            }
            "format" -> {
                if (pos.size >= 2) out.add(ScriptStep("erase", "format ${pos[1]} (erase only)", partition = pos[1]))
            }
            "set_active" -> {
                if (pos.size >= 2) out.add(ScriptStep("set_active", "set active slot ${pos[1]}", partition = pos[1].removePrefix("_")))
            }
            "reboot", "reboot-bootloader", "reboot-recovery", "reboot-fastboot", "continue" -> {
                val c = when {
                    base == "reboot" -> when (pos.getOrNull(1)?.lowercase()) {
                        "bootloader" -> "reboot-bootloader"
                        "recovery" -> "reboot-recovery"
                        "fastboot" -> "reboot-fastboot"
                        else -> "reboot"
                    }
                    base == "continue" -> "reboot"
                    else -> base
                }
                out.add(ScriptStep("reboot", c.replace('-', ' '), cmd = c))
            }
            "getvar" -> {
                if (pos.size >= 2) out.add(ScriptStep("cmd", "getvar ${pos[1]}", cmd = "getvar:${pos[1]}"))
            }
            "oem", "flashing" -> {
                val c = pos.joinToString(" ")
                out.add(ScriptStep("cmd", c, cmd = c))
            }
            "delete-logical-partition", "create-logical-partition", "resize-logical-partition" -> {
                if (pos.size >= 2) {
                    val c = base + ":" + pos.drop(1).joinToString(":")
                    out.add(ScriptStep("cmd", c.replace(':', ' '), cmd = c))
                }
            }
            "snapshot-update" -> {
                val c = base + (if (pos.size >= 2) ":" + pos[1] else "")
                out.add(ScriptStep("cmd", c.replace(':', ' '), cmd = c))
            }
            "devices", "help", "version" -> { }
            else -> out.add(ScriptStep("note", "unsupported: ${pos.joinToString(" ")}"))
        }
    }

    /** After a reboot-bootloader / reboot-fastboot the phone re-enumerates on USB: wait and reconnect. */
    private fun reconnect(timeoutMs: Long): FastbootClient {
        val end = System.currentTimeMillis() + timeoutMs
        var asked = false
        Thread.sleep(3000)
        while (System.currentTimeMillis() < end) {
            for (d in usb.deviceList.values) {
                if (FastbootClient.findInterface(d) == null) continue
                if (usb.hasPermission(d)) {
                    connectBlocking(d)
                    client?.let { return it }
                } else if (!asked) {
                    asked = true
                    log("  ℹ allow USB access on the screen")
                    val pi = PendingIntent.getBroadcast(
                        ctx, 0, Intent(ACTION_PERM).setPackage(ctx.packageName), PendingIntent.FLAG_MUTABLE
                    )
                    usb.requestPermission(d, pi)
                }
            }
            Thread.sleep(1000)
        }
        throw FastbootException("Device did not come back in fastboot mode")
    }

    fun runScript() {
        val steps = scriptSteps.toList()
        if (steps.isEmpty() || busy) return
        var c: FastbootClient = client ?: run { log("No fastboot device connected"); return }
        val skip = skipMissing
        busy = true; progress = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try {
                log("▶ Script: $scriptName — ${steps.size} step(s)")
                steps.forEachIndexed { i, s ->
                    log("[${i + 1}/${steps.size}] ${s.label}")
                    val frac = { fr: Float -> progress = (i + fr) / steps.size }
                    try {
                        when (s.kind) {
                            "flash" -> {
                                val u = s.uri
                                if (u == null) {
                                    if (skip) { log("  ⚠ skipped — ${s.fileName} not found"); return@forEachIndexed }
                                    throw FastbootException("${s.fileName} not found in the images folder")
                                }
                                flashOne(c, FlashItem(u, s.fileName, s.size, s.partition), u, s.slot ?: slotMode, s.verity || disableVerity, frac)
                            }
                            "erase" -> { c.command("erase:${s.partition}", 300000) { log(it) } }
                            "wipe" -> {
                                c.command("erase:userdata", 300000) { log(it) }
                                try { c.command("erase:metadata", 120000) { log(it) } } catch (e: Exception) { log("  metadata skipped: ${e.message}") }
                            }
                            "set_active" -> { c.command("set_active:${s.partition}"); refreshSlot(c) }
                            "cmd" -> {
                                val r = c.command(s.cmd, 120000) { log(it) }
                                if (r.isNotEmpty()) log(r)
                            }
                            "reboot" -> {
                                val last = i == steps.lastIndex
                                c.sendNoReply(s.cmd)
                                disconnect()
                                if (last) {
                                    log("  ✔ device is rebooting")
                                } else if (s.cmd == "reboot") {
                                    log("  ✔ device rebooted — remaining steps skipped")
                                    return@launch
                                } else {
                                    log("  waiting for the device to come back …")
                                    c = reconnect(90000)
                                    log("  ✔ device is back")
                                }
                            }
                            else -> log("  ⚠ not supported — skipped")
                        }
                    } catch (e: Exception) {
                        hint(e.message)
                        throw FastbootException("Step ${i + 1} failed (${s.label}): ${e.message}")
                    }
                    progress = (i + 1f) / steps.size
                }
                log("✔ Script finished")
            } catch (e: Exception) {
                log("✖ ${e.message}")
            } finally { busy = false; progress = 0f }
        }
    }

    override fun onCleared() { client?.close(); adb?.close() }
}
