package com.fairyteam.fairyflasherx

import android.content.Intent
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Launch
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF242638)
private val Muted = Color(0xFF7D8193)
private val Violet = Color(0xFF8875E8)
private val SurfaceWhite = Color(0xFFFFFFFF)
private val Canvas = Color(0xFFF5F7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Violet, background = Canvas, surface = SurfaceWhite)) {
                FairyHome(
                    usbCount = { (getSystemService(USB_SERVICE) as UsbManager).deviceList.size },
                    openChannel = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/FairysTeamBase"))) },
                    openModule = { title ->
                        startActivity(Intent(this, ModuleInfoActivity::class.java).putExtra("title", title))
                    }
                )
            }
        }
    }
}

@Composable
private fun FairyHome(usbCount: () -> Int, openChannel: () -> Unit, openModule: (String) -> Unit) {
    var connected by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { connected = usbCount() }
    val modules = listOf(
        Module("ADB Console", "Command interface", Icons.Rounded.Terminal),
        Module("Fastboot", "Bootloader tools", Icons.Rounded.Bolt),
        Module("App Manager", "Packages & APKs", Icons.Rounded.Apps),
        Module("File Manager", "Browse & transfer", Icons.Rounded.FolderOpen),
        Module("Device Info", "Hardware details", Icons.Rounded.Android),
        Module("Backup Tools", "Supported operations", Icons.Rounded.CloudUpload),
        Module("USB Devices", "Host connection status", Icons.Rounded.Cable),
        Module("Custom Commands", "Saved command presets", Icons.Rounded.Code)
    )

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFAFBFF), Color(0xFFF0F2FA), Color(0xFFF9FAFD))))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(46.dp).shadow(10.dp, RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFFA99BFF), Violet, Color(0xFF6D7EEA))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text("F", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("FAIRY FLASHER", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Ink, letterSpacing = 1.sp)
                    Text("X  ·  ANDROID TOOLKIT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Muted, letterSpacing = 2.sp)
                }
                IconButton(onClick = openChannel, modifier = Modifier.background(Color.White.copy(alpha = .82f), CircleShape).border(1.dp, Color.White, CircleShape)) {
                    Icon(Icons.Rounded.Launch, contentDescription = "Open FairyTeam Telegram", tint = Violet)
                }
            }
            Spacer(Modifier.height(24.dp))
            Box(Modifier.fillMaxWidth().shadow(15.dp, RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFFFFFFFF), Color(0xFFF1EEFF), Color(0xFFE9F1FF))), RoundedCornerShape(28.dp)).border(1.dp, Color.White, RoundedCornerShape(28.dp)).padding(22.dp)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color(0xFFE9E5FF), shape = RoundedCornerShape(50)) {
                            Text("  WHITE LIQUID GLASS  ", modifier = Modifier.padding(vertical = 7.dp), color = Color(0xFF6856C8), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Rounded.Memory, contentDescription = null, tint = Color(0xFF9384E8), modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Your Android.\nYour tools.", fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Spacer(Modifier.height(8.dp))
                    Text("A clean workspace for ADB, Fastboot and device utilities.", fontSize = 13.sp, lineHeight = 19.sp, color = Muted)
                    Spacer(Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(if (connected > 0) Color(0xFF2EBF8A) else Color(0xFFB5B7C5), CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(if (connected > 0) "$connected USB device(s) visible to Android" else "No USB device detected", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { connected = usbCount() }) { Text("Refresh") }
                    }
                }
            }
            Spacer(Modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("TOOLS", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = Ink)
                Spacer(Modifier.weight(1f))
                Text("CORE WORKSPACE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Muted, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().height(380.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), userScrollEnabled = false) {
                items(modules) { module -> ModuleCard(module) { openModule(module.name) } }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(22.dp)).background(Color.White.copy(alpha = .9f), RoundedCornerShape(22.dp)).border(1.dp, Color.White, RoundedCornerShape(22.dp)).clickable(onClick = openChannel).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFFEAE6FF), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("✦", color = Violet, fontSize = 24.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("FairysTeamBase", color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Join the Telegram channel", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Rounded.Launch, contentDescription = "Open channel", tint = Violet)
            }
            Spacer(Modifier.height(17.dp))
            Text("Built by @yooitachiijod", modifier = Modifier.fillMaxWidth().clickable(onClick = openChannel), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(7.dp))
            Text("FAIRY FLASHER X  •  EARLY PREVIEW", modifier = Modifier.fillMaxWidth(), color = Color(0xFFA6A9B6), fontSize = 9.sp, letterSpacing = 1.4.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(28.dp))
        }
    }
}

private data class Module(val name: String, val subtitle: String, val icon: ImageVector)

@Composable
private fun ModuleCard(module: Module, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().height(174.dp).shadow(7.dp, RoundedCornerShape(23.dp)).background(Color.White.copy(alpha = .92f), RoundedCornerShape(23.dp)).border(1.dp, Color.White, RoundedCornerShape(23.dp)).clickable(onClick = onClick).padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Box(Modifier.size(43.dp).background(Brush.linearGradient(listOf(Color(0xFFF1EEFF), Color(0xFFEAF2FF))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Icon(module.icon, contentDescription = null, tint = Violet, modifier = Modifier.size(24.dp))
        }
        Column {
            Text(module.name, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(module.subtitle, color = Muted, fontSize = 11.sp, maxLines = 2, lineHeight = 15.sp)
        }
    }
}
