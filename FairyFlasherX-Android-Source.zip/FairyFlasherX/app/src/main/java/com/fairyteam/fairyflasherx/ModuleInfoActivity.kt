package com.fairyteam.fairyflasherx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ModuleInfoActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("title") ?: "Tool"
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF8875E8), background = Color(0xFFF5F7FB))) {
                Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FB)).padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { finish() }) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Back") }
                        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF242638))
                    }
                    Spacer(Modifier.height(20.dp))
                    Surface(color = Color.White, shape = RoundedCornerShape(24.dp), shadowElevation = 5.dp) {
                        Column(Modifier.fillMaxWidth().padding(22.dp)) {
                            Text("Module planned", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF242638))
                            Spacer(Modifier.height(9.dp))
                            Text("This screen is a UI foundation only. The $title engine has not been integrated yet, so no device-changing command will run from this preview.", color = Color(0xFF74798B), fontSize = 14.sp, lineHeight = 21.sp)
                        }
                    }
                }
            }
        }
    }
}
