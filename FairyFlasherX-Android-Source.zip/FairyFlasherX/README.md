# FAIRY FLASHER X — Android starter

White liquid-glass Compose UI, developer branding (`Built by @yooitachiijod`), and clickable Telegram channel link (`https://t.me/FairysTeamBase`).

## Important status
This is an early UI foundation, not a complete Bugjaeger replacement. Dashboard modules currently open an honest placeholder screen; they do **not** execute ADB/Fastboot commands or flash partitions yet. USB count only shows USB devices visible to Android's USB host API, not verified ADB devices.

## Build APK using GitHub Actions
1. Create a new private GitHub repository and upload the contents of this folder (the files inside `FairyFlasherX`, not the enclosing folder).
2. Open **Actions** and run **Build FairyFlasher X APK** (or push to `main`).
3. Download artifact `FairyFlasherX-debug-apk` from the completed workflow; it contains `app-debug.apk`.

Build locally with JDK 17, Android SDK platform 35/build-tools, and Gradle 8.9: `gradle assembleDebug`.
